from django.http import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def index(request):
    return render(request,'index.html')

def Projects(request):
    return render(request,'Projects.html')

def CV(request):
    return render(request,'CV.html')

def Contact(request):
    return render(request,'Contact.html')