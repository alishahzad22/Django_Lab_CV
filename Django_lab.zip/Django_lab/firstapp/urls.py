from django.urls import path
from . import views

urlpatterns = [
    path('',views.index, name='Home'),
    path('index',views.index, name='Home'),
    path('Projects',views.Projects, name='Projects'),
    path('CV',views.CV, name='CV'),
    path('Contact',views.Contact, name='Contact'),

]